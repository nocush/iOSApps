//
//  Image.swift
//  Lab9_1
//
//  Created by Mateusz Bartoszek on 07/05/2023.
//

import Foundation

class MyImage{
    var title: String
    var path: String
    
    init(title: String, path: String) {
        self.title = title
        self.path = path
    }
}
