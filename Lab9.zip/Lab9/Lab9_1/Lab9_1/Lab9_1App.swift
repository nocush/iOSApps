//
//  Lab9_1App.swift
//  Lab9_1
//
//  Created by Mateusz Bartoszek on 07/05/2023.
//

import SwiftUI

@main
struct Lab9_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
