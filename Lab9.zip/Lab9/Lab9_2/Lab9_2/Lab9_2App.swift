//
//  Lab9_2App.swift
//  Lab9_2
//
//  Created by Mateusz Bartoszek on 07/05/2023.
//

import SwiftUI

@main
struct Lab9_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
