//
//  Lab9_4App.swift
//  Lab9_4
//
//  Created by Mateusz Bartoszek on 07/05/2023.
//

import SwiftUI

@main
struct Lab9_4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
