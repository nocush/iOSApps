//
//  Car.swift
//  Lab9_4
//
//  Created by Mateusz Bartoszek on 07/05/2023.
//

import Foundation

struct Car: Hashable{
    var model: String
    var manufacturer: String
    var logo: String
}
