//
//  Lab9_3App.swift
//  Lab9_3
//
//  Created by Mateusz Bartoszek on 07/05/2023.
//

import SwiftUI

@main
struct Lab9_3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
